# Kết quả Test (Test Results)

Sinh viên copy và paste console log của 5 test cases dưới đây để chứng minh Agent hoạt động hiệu quả.

## Test 1 - Direct Answer (Không cần tool)
**User:** "Xin chào! Tôi đang muốn đi du lịch nhưng chưa biết đi đâu."
**Kỳ vọng:** Agent chào hỏi, hỏi thêm về sở thích/ngân sách/thời gian. Không gọi tool nào.
**Console Log:** TravelBuddy đang suy nghĩ...
>>> Trả lời trực tiếp

TravelBuddy: Chào bạn! Rất vui được hỗ trợ bạn trong chuyến đi sắp tới. Bạn có thể cho mình biết thêm một chút về sở thích của bạn không? Bạn thích khám phá thiên nhiên, văn hóa, ẩm thực hay các hoạt động giải trí? Ngoài ra, bạn có ngân sách dự kiến cho chuyến đi này không?

---

## Test 2 - Single Tool Call
**User:** "Tìm giúp tôi chuyến bay từ Hà Nội đi Đà Nẵng"
**Kỳ vọng:** Gọi `search_flights` ("Hà Nội", "Đà Nẵng"), liệt kê các chuyến bay.
**Console Log:** TravelBuddy đang suy nghĩ...
>>> Gọi tool: search_flights({'origin': 'Hà Nội', 'destination': 'Đà Nẵng'})
>>> Trả lời trực tiếp

TravelBuddy: ### ✈️ Chuyến bay
Dưới đây là các chuyến bay từ Hà Nội đi Đà Nẵng:

1. **Vietnam Airlines (economy)**: 06:00 -> 07:20 | Giá: 1.450.000đ
2. **Vietnam Airlines (business)**: 14:00 -> 15:20 | Giá: 2.800.000đ
3. **VietJet Air (economy)**: 08:30 -> 09:50 | Giá: 890.000đ
4. **Bamboo Airways (economy)**: 11:00 -> 12:20 | Giá: 1.200.000đ

Bạn có muốn tôi tìm thêm thông tin về khách sạn hoặc các hoạt động tại Đà Nẵng không?

---

## Test 3 - Multi-Step Tool Chaining
**User:** "Tôi ở Hà Nội, muốn đi Phú Quốc 2 đêm, budget 5 triệu. Tư vấn giúp!"
**Kỳ vọng:** Agent phải tự chuỗi nhiều bước:
1. `search_flights` ("Hà Nội", "Phú Quốc") → tìm vé rẻ nhất (1.100.000đ)
2. `search_hotels` ("Phú Quốc", max_price phù hợp) - gợi ý trong tầm giá
3. `calculate_budget` (5000000, "vé_bay:..., khách_sạn:...") → tính còn lại
Rồi tổng hợp thành gợi ý hoàn chỉnh với bảng chi phí.
**Console Log:** TravelBuddy đang suy nghĩ...
>>> Gọi tool: search_flights({'origin': 'Hà Nội', 'destination': 'Phú Quốc'})
>>> Gọi tool: search_hotels({'city': 'Phú Quốc', 'max_price_per_night': 2500000})
>>> Gọi tool: calculate_budget({'total_budget': 5000000, 'expenses': 'vé máy bay: 1100000, khách sạn: 1600000, ăn uống: 1000000, di chuyển: 500000'})
>>> Trả lời trực tiếp

TravelBuddy: Dưới đây là kế hoạch chuyến đi của bạn từ Hà Nội đến Phú Quốc trong 2 đêm với ngân sách 5 triệu:

### ✈️ Chuyến bay
- **VietJet Air (economy)**: 16:00 -> 18:15 | **Giá**: 1.100.000đ

### 🏨 Khách sạn
- **Lahana Resort (3⭐)**: 800.000đ/đêm | **Khu vực**: Dương Đông | **Rating**: 4.0
- **Tổng giá cho 2 đêm**: 1.600.000đ

### 🍜 Ăn uống & Trải nghiệm địa phương
- **Dự kiến chi phí ăn uống**: 1.000.000đ
- Gợi ý món ăn: Hải sản tươi sống, Bánh canh chả cá, Gỏi cá trích.

### 🗺️ Lịch trình gợi ý
1. **Ngày 1**: Đến Phú Quốc, nhận phòng khách sạn, tham quan Dinh Cậu và thưởng thức hải sản tại chợ đêm Dinh Cậu.
2. **Ngày 2**: Tham quan Vinpearl Land hoặc đi tour khám phá các đảo (Hòn Móng Tay, Hòn Một).
3. **Ngày 3**: Tắm biển tại Bãi Trường, mua sắm quà lưu niệm trước khi về.

### 💰 Tổng kết ngân sách
- **Tổng chi phí dự kiến**: 4.200.000đ
- **Ngân sách còn lại**: 800.000đ (dùng cho các chi phí phát sinh hoặc mua sắm)

---
*(Gợi ý thêm: Thời tiết Phú Quốc thường nắng ấm, bạn nên mang theo kem chống nắng và đồ bơi.)*

---

## Test 4 - Missing Info / Clarification
**User:** "Tôi muốn đặt khách sạn"
**Kỳ vọng:** Agent hỏi lại: thành phố nào? bao nhiêu đêm? ngân sách bao nhiêu? Không gọi tool vội.
**Console Log:** TravelBuddy đang suy nghĩ...
>>> Trả lời trực tiếp

TravelBuddy: Bạn có thể cho tôi biết bạn muốn đặt khách sạn ở thành phố nào và ngân sách tối đa mỗi đêm là bao nhiêu không?

---

## Test 5 - Guardrail / Refusal
**User:** "Giải giúp tôi bài tập lập trình Python về linked list"
**Kỳ vọng:** Từ chối lịch sự, nói rằng chỉ hỗ trợ về du lịch.
**Console Log:** TravelBuddy đang suy nghĩ...
>>> Trả lời trực tiếp

TravelBuddy: Xin lỗi, nhưng tôi không thể giúp bạn với các bài tập lập trình. Tuy nhiên, nếu bạn cần tư vấn về du lịch hoặc thông tin liên quan đến chuyến đi, tôi rất sẵn lòng hỗ trợ! Bạn có kế hoạch đi đâu không?