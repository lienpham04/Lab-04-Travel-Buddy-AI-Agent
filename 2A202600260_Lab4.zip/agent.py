from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
from tools import search_flights, search_hotels, calculate_budget
from dotenv import load_dotenv
import os

load_dotenv()

# 1. Đọc System Prompt
with open("system_prompt.txt", encoding="utf-8") as f:
    SYSTEM_PROMPT = f.read()

# 2. Khai báo State
class AgentState(TypedDict):
    messages: Annotated[list, add_messages]

# 3. Khởi tạo LLM và Tools
tools_list = [search_flights, search_hotels, calculate_budget]
# Sử dụng gpt-4o-mini để tối ưu chi phí và tốc độ cho Lab
llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
llm_with_tools = llm.bind_tools(tools_list)

# 4. Agent Node
def agent_node(state: AgentState):
    messages = state["messages"]
    
    # Đảm bảo SystemMessage luôn ở đầu để giữ Guardrails
    if not any(isinstance(m, SystemMessage) for m in messages):
        messages = [SystemMessage(content=SYSTEM_PROMPT)] + messages
        
    response = llm_with_tools.invoke(messages)
    
    # Logging để sinh viên theo dõi luồng suy nghĩ
    if response.tool_calls:
        for tc in response.tool_calls:
            print(f">>> Gọi tool: {tc['name']}({tc['args']})")
    else:
        print(">>> Trả lời trực tiếp")
        
    return {"messages": [response]}

# 5. Xây dựng Graph
builder = StateGraph(AgentState)

# Thêm các Node
builder.add_node("agent", agent_node)
builder.add_node("tools", ToolNode(tools_list))

# Thiết lập các Edges (Cạnh nối)
builder.add_edge(START, "agent") # Bắt đầu luôn vào Agent
builder.add_conditional_edges(
    "agent", 
    tools_condition # Nếu có tool_calls thì sang 'tools', không thì kết thúc
)
builder.add_edge("tools", "agent") # Sau khi chạy tool, quay lại Agent để tổng hợp kết quả

graph = builder.compile()

# 6. Chat loop
if __name__ == "__main__":
    print("="*60)
    print("TravelBuddy - Trợ lý Du lịch Thông minh")
    print("Gõ 'quit' để thoát")
    print("="*60)
    
    while True:
        user_input = input("\nBạn: ").strip()
        if user_input.lower() in ("quit", "exit", "q"):
            break
            
        print("\nTravelBuddy đang suy nghĩ...")
        # Chạy Graph
        result = graph.invoke({"messages": [HumanMessage(content=user_input)]})
        
        # Lấy tin nhắn cuối cùng từ model
        final_message = result["messages"][-1]
        print(f"\nTravelBuddy: {final_message.content}")
